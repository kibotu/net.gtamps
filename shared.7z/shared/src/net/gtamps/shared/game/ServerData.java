package net.gtamps.shared.game;

public class ServerData {

    public final String host;
    public final int port;

    public ServerData(final String host, final int port) {
        super();
        this.host = host;
        this.port = port;
    }

}
