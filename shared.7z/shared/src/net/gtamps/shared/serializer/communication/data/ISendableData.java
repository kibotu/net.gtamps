package net.gtamps.shared.serializer.communication.data;

import java.io.Serializable;

/**
 * @deprecated use {@link AbstractSendableData} instead
 */
@Deprecated
public interface ISendableData extends Serializable {
}
