package net.gtamps.shared.serializer.communication;

import java.io.Serializable;

/**
 * @deprecated use {@link AbstractSendable} instead
 */
@Deprecated
public interface ISendable extends Serializable {
}
