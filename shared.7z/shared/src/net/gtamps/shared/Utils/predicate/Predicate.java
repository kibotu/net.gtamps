package net.gtamps.shared.Utils.predicate;

public interface Predicate<T> {
    boolean isTrueFor(T x);
}
