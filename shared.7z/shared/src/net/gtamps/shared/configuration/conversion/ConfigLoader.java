package net.gtamps.shared.configuration.conversion;

import net.gtamps.shared.configuration.Configuration;

public interface ConfigLoader {

    public Configuration loadConfig();

}
